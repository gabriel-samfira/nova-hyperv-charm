VPN as a Service
=====================

`API Specification`_

.. _API Specification: http://docs.openstack.org/api/openstack-network/2.0/content/vpnaas_ext.html

Plugin
------
.. automodule:: neutron.services.vpn.plugin

.. autoclass:: VPNPlugin
   :members:

Database layer
--------------

.. automodule:: neutron.db.vpn.vpn_db

.. autoclass:: VPNPluginDb
   :members:
